document.getElementsByTagName("head")[0].insertAdjacentHTML(
    "beforeend",
    "<style>* {font-family: monospace;}</stye>");
